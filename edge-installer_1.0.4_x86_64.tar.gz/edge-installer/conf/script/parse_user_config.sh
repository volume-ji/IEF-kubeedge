#!/bin/sh

CERT_PATH=/opt/IEF/Cert
VERSION_FILE=/opt/IEF/version
ENCRYPT_TOOL_FILE="encrypt_tool"
ENCRYPT_CERT_SUFFIX="_crypto"
INSTALLER_PATH=/opt/edge-installer
MATERIAL_PATH=/opt/material
PROXYNOTSET="ProxyNotSet"
NO_NODE_TYPE="NOTYPE"
NODE_TYPE_FILE=/opt/IEF/NODE_INFO
SYSTEM_KEY_FILE="system/sys_private_cert.key"
SYSTEM_CERT_FILE="system/sys_private_cert.crt"

copy_material() {
    if [ -d ${MATERIAL_PATH} ]; then
        if [ -f ${MATERIAL_PATH}/common_shared.key ] && [ -f ${MATERIAL_PATH}/root.key ]; then
            if [ ! -f ${INSTALLER_PATH}/common_shared.key ] || [ ! -f ${INSTALLER_PATH}/root.key ]; then
                cp -f ${MATERIAL_PATH}/common_shared.key ${INSTALLER_PATH}
                cp -f ${MATERIAL_PATH}/root.key ${INSTALLER_PATH}
                chmod 600 ${INSTALLER_PATH}/common_shared.key
                chmod 600 ${INSTALLER_PATH}/root.key
            fi
        fi
    fi
}
backup_material() {
    if [ -d ${MATERIAL_PATH} ]; then
        if [ -f ${MATERIAL_PATH}/common_shared.key ] && [ -f ${MATERIAL_PATH}/root.key ]; then
            chmod -R 700 ${MATERIAL_PATH}
            chmod 600 ${INSTALLER_PATH}/common_shared.key
            chmod 600 ${INSTALLER_PATH}/root.key
            return
        else
            # 删除物料备份目录（物料不完整）
            rm -rf ${MATERIAL_PATH}
        fi
    fi

    mkdir -p ${MATERIAL_PATH}
    # 检查物料是否存在
    if [ ! -f ${INSTALLER_PATH}/common_shared.key ]; then
        echo "not found ${INSTALLER_PATH}/common_shared.key"
        exit 1
    fi
    if [ ! -f ${INSTALLER_PATH}/root.key ]; then
        echo "not found ${INSTALLER_PATH}/root.key, please check"
        exit 1
    fi

    # 拷贝物料到/opt/material
    cp ${INSTALLER_PATH}/common_shared.key ${MATERIAL_PATH}
    cp ${INSTALLER_PATH}/root.key ${MATERIAL_PATH}
    chmod -R 700 ${MATERIAL_PATH}
    chmod 600 ${INSTALLER_PATH}/common_shared.key
    chmod 600 ${INSTALLER_PATH}/root.key
}

encrypt_cert_key() {
    if [  -z "${PRIVATE_KEY_FILE}" ] || [ "${PRIVATE_KEY_FILE}" = "" ]; then
        echo "PRIVATE_KEY_FILE is null, please check."
        exit 1
    fi
    cert_key_filename=`echo ${PRIVATE_KEY_FILE##*/} | awk -F "." '{print $1}'`
    if [ -z "${cert_key_filename}" ] || [ "${cert_key_filename}" = "" ]; then
        echo "Parse cert key file failed, please check."
        exit 1
    fi

    encrypt_cert_filename=${cert_key_filename}${ENCRYPT_CERT_SUFFIX}.key

    if [ -f ${CERT_PATH}/${encrypt_cert_filename} ]; then
        backup_material
        echo ${CERT_PATH}/${encrypt_cert_filename}
        return
    fi

    cd ${INSTALLER_PATH}
    ./${ENCRYPT_TOOL_FILE} -op=encrypt -srcName=${CERT_PATH}/${PRIVATE_KEY_FILE} -dstName=${CERT_PATH}/${encrypt_cert_filename}
    if [ $? -ne 0 ] || [ ! -f "${CERT_PATH}/${encrypt_cert_filename}" ]; then
        echo "Encrypt cert file failed, please check."
        exit 1
    fi
    if [ -f ${CERT_PATH}/${PRIVATE_KEY_FILE} ]; then
        cp ${CERT_PATH}/${PRIVATE_KEY_FILE} ${CERT_PATH}/${PRIVATE_KEY_FILE}-bak
    fi
    backup_material
    echo ${CERT_PATH}/${encrypt_cert_filename}
}

encrypt_private_cert() {
    if [  -z "${PRIVATE_CERT_FILE}" ] || [ "${PRIVATE_CERT_FILE}" = "" ]; then
       echo "PRIVATE_CERT_FILE is null, please check."
       exit 1
    fi
    private_cert_filename=`echo ${PRIVATE_CERT_FILE##*/} | awk -F "." '{print $1}'`
    if [ -z "${private_cert_filename}" ] || [ "${private_cert_filename}" = "" ]; then
       echo "Parse private cert file failed, please check."
       exit 1
    fi

    encrypt_private_cert_filename=${private_cert_filename}${ENCRYPT_CERT_SUFFIX}.crt

    if [ -f ${CERT_PATH}/${encrypt_private_cert_filename} ]; then
       backup_material
       echo ${CERT_PATH}/${encrypt_private_cert_filename}
       return
    fi

    cd ${INSTALLER_PATH}
    ./${ENCRYPT_TOOL_FILE} -op=encrypt -srcName=${CERT_PATH}/${PRIVATE_CERT_FILE} -dstName=${CERT_PATH}/${encrypt_private_cert_filename}
    if [ $? -ne 0 ] || [ ! -f "${CERT_PATH}/${encrypt_private_cert_filename}" ]; then
       echo "Encrypt cert file failed, please check."
       exit 1
    fi
    if [ -f ${CERT_PATH}/${PRIVATE_CERT_FILE} ]; then
       cp ${CERT_PATH}/${PRIVATE_CERT_FILE} ${CERT_PATH}/${PRIVATE_CERT_FILE}-bak
    fi
    backup_material
    echo ${CERT_PATH}/${encrypt_private_cert_filename}
}

encrypt_file() {
    filename=$1
    if [  -z "${filename}" ] || [ "${filename}" = "" ]; then
       echo "filename is null which need encrypt, please check."
       exit 1
    fi
    private_name=`echo ${filename} | awk -F "." '{print $1}'`
    if [ -z "${private_name}" ] || [ "${private_name}" = "" ]; then
       echo "Parse file private name failed, please check."
       exit 1
    fi
    type_name=`echo ${filename##*/} | awk -F "." '{print $2}'`
    if [ -z "${type_name}" ] || [ "${type_name}" = "" ]; then
       echo "Parse file type name failed, please check."
       exit 1
    fi

    encrypt_filename=${private_name}${ENCRYPT_CERT_SUFFIX}.${type_name}

    if [ -f ${CERT_PATH}/${encrypt_filename} ]; then
       backup_material
       echo ${CERT_PATH}/${encrypt_filename}
       return
    fi

    cd ${INSTALLER_PATH}
    ./${ENCRYPT_TOOL_FILE} -op=encrypt -srcName=${CERT_PATH}/${filename} -dstName=${CERT_PATH}/${encrypt_filename}
    if [ $? -ne 0 ] || [ ! -f "${CERT_PATH}/${encrypt_filename}" ]; then
       echo "Encrypt file failed, please check."
       exit 1
    fi
    if [ -f ${CERT_PATH}/${filename} ]; then
       rm -f ${CERT_PATH}/${filename}
    fi
    backup_material
    echo ${CERT_PATH}/${encrypt_filename}
}

get_node_id() {
	NODE_HOST_NAME=`cat ${CERT_PATH}/user_config | grep -Po '"NODE_ID": *".*?"' | sed 's/"//g' | cut -d":" -f2 | sed s/[[:space:]]//g`
    if [ $? -ne 0 ] || [ -z "${NODE_HOST_NAME+x}" ] || [ "${NODE_HOST_NAME}" = "" ]; then
        echo "Parse node id failed!"
        exit 1
    fi
	echo ${NODE_HOST_NAME}
}

get_project_id() {
    EDGE_NAMESPACE=`cat ${CERT_PATH}/user_config | grep -Po '"PROJECT_ID": *".*?"' | sed 's/"//g' | cut -d":" -f2 | sed s/[[:space:]]//g`
    if [ $? -ne 0 ] || [ -z "${EDGE_NAMESPACE+x}" ] || [ "${EDGE_NAMESPACE}" = "" ]; then
        echo "Parse project id failed!"
        exit 1
    fi
    echo ${EDGE_NAMESPACE}
}

get_private_cert_file() {
    PRIVATE_CERT_FILE=`cat ${CERT_PATH}/user_config | grep -Po '"PRIVATE_CERTIFICATE": *".*?"' | sed 's/"//g' | sed 's/PRIVATE_CERTIFICATE://' | sed s/[[:space:]]//g`
    if [ $? -ne 0 ] || [ -z "${PRIVATE_CERT_FILE+x}" ] || [ "${PRIVATE_CERT_FILE}" = "" ]; then
        echo "Parse private cert file failed!"
        exit 1
    fi
    if [ -f ${INSTALLER_PATH}/${ENCRYPT_TOOL_FILE} ]; then
        encrypt_private_cert
    else
        echo ${CERT_PATH}/${PRIVATE_CERT_FILE}
    fi
    copy_material
}

get_private_key_file() {
    PRIVATE_KEY_FILE=`cat ${CERT_PATH}/user_config | grep -Po '"PRIVATE_KEY": *".*?"' | sed 's/"//g' | sed 's/PRIVATE_KEY://' | sed s/[[:space:]]//g`
    if [ $? -ne 0 ] || [ -z "${PRIVATE_KEY_FILE+x}" ] || [ "${PRIVATE_KEY_FILE}" = "" ]; then
        echo "Parse private key file failed!"
        exit 1
    fi
    if [ -f ${INSTALLER_PATH}/${ENCRYPT_TOOL_FILE} ]; then
        encrypt_cert_key
    else
        echo ${CERT_PATH}/${PRIVATE_KEY_FILE}
    fi
    copy_material
}

get_system_cert_file() {
    if [ -z "${SYSTEM_CERT_FILE+x}" ] || [ "${SYSTEM_CERT_FILE}" = "" ]; then
        echo "Parse system cert file failed!"
        exit 1
    fi
    if [ -f ${INSTALLER_PATH}/${ENCRYPT_TOOL_FILE} ]; then
        encrypt_file ${SYSTEM_CERT_FILE}
    else
        echo ${CERT_PATH}/${SYSTEM_CERT_FILE}
    fi
    copy_material
}

get_system_key_file() {
    if [ -z "${SYSTEM_KEY_FILE+x}" ] || [ "${SYSTEM_KEY_FILE}" = "" ]; then
        echo "Parse system key file failed!"
        exit 1
    fi
    if [ -f ${INSTALLER_PATH}/${ENCRYPT_TOOL_FILE} ]; then
        encrypt_file ${SYSTEM_KEY_FILE}
    else
        echo ${CERT_PATH}/${SYSTEM_KEY_FILE}
    fi
    copy_material
}

get_master_url() {
    MASTER_ADDR_FOREDGE=`cat ${CERT_PATH}/user_config | grep -Po '"MASTER_URL": *".*?"' | sed 's/"//g' | sed 's/MASTER_URL://' | sed s/[[:space:]]//g`
    if [ $? -ne 0 ] || [ -z "${MASTER_ADDR_FOREDGE+x}" ] || [ "${MASTER_ADDR_FOREDGE}" = "" ]; then
        echo "Parse master url failed!"
        exit 1
    fi
    echo ${MASTER_ADDR_FOREDGE}
}

get_root_cert_file() {
    ROOT_CA_FILE=`cat ${CERT_PATH}/user_config | grep -Po '"ROOT_CA": *".*?"' | sed 's/"//g' | sed 's/ROOT_CA://' | sed s/[[:space:]]//g`
    if [ $? -ne 0 ] || [ -z "${ROOT_CA_FILE+x}" ] || [ "${ROOT_CA_FILE}" = "" ]; then
        echo "Parse root cert file failed!"
        exit 1
    fi
    echo ${CERT_PATH}/${ROOT_CA_FILE}
}

get_http_proxy() {
    HTTP_PROXY=`cat ${CERT_PATH}/user_config | grep -Po '"HTTP_PROXY": *".*?"' | sed 's/"//g' | sed 's/HTTP_PROXY://' | sed s/[[:space:]]//g`
    if [ $? -ne 0 ] || [ -z "${HTTP_PROXY+x}" ] || [ "${HTTP_PROXY}" = "" ]; then
        echo "${PROXYNOTSET}"
        return
    fi
    echo ${HTTP_PROXY}
}

get_https_proxy() {
    HTTPS_PROXY=`cat ${CERT_PATH}/user_config | grep -Po '"HTTPS_PROXY": *".*?"' | sed 's/"//g' | sed 's/HTTPS_PROXY://' | sed s/[[:space:]]//g`
    if [ $? -ne 0 ] || [ -z "${HTTP_PROXY+x}" ] || [ "${HTTP_PROXY}" = "" ]; then
        echo "${PROXYNOTSET}"
        return
    fi
    echo ${HTTPS_PROXY}
}

get_current_ief_version() {
    if [ ! -f ${VERSION_FILE} ]; then
        echo "No file ${VERSION_FILE}"
        exit 1
    fi
    version=`cat ${VERSION_FILE} | grep "ief" | cut -d":" -f2`
    if [ $? -ne 0 ]; then
        echo "Get current ief version failed!"
        exit 1
    fi
    echo ${version}
}

write_ief_version() {
    version=$1
    if [ ! -f ${VERSION_FILE} ]; then
        echo "No file ${VERSION_FILE}"
        exit 1
    fi
    if [ -z `cat ${VERSION_FILE} | grep "ief"`]; then
        echo "ief:${version}" >> ${VERSION_FILE}
    else
        sed -i "s|ief:.*|ief:${version}|g" ${VERSION_FILE}
    fi
}

get_node_type() {
    if [ ! -f ${NODE_TYPE_FILE} ] || [ ! -s ${NODE_TYPE_FILE} ]; then
        echo ${NO_NODE_TYPE}
        return
    fi

    node_type=`cat ${NODE_TYPE_FILE} | grep  'node_type' |sed 's/node_type://'|sed 's/^[ \t]*//g'`
    if [ $? != 0 ] || [ -z "${node_type+x}" ] || [ "${node_type}" = "" ]; then
        echo ${NO_NODE_TYPE}
        return
    fi
    echo ${node_type}
}

modify_permission() {
    # Cert
    if [ ! -d ${CERT_PATH} ]; then
        echo "${CERT_PATH} doesn't existed, please check."
        exit 1
    fi
    chmod -R 700 ${CERT_PATH}
    chmod 600 ${CERT_PATH}/*.crt
    chmod 600 ${CERT_PATH}/*.key
    chmod 640 ${CERT_PATH}/user_config
    if [ -d ${CERT_PATH}/system ]; then
        chmod 600 ${CERT_PATH}/system/*.crt
        chmod 600 ${CERT_PATH}/system/*.key
    fi
}

print_help() {
    echo "Usage: sudo $0 {node_id|project_id|private_cert_file|private_key_file|master_url|root_cert_file|system_cert_file|system_key_file}"
}

if [ ! -d ${CERT_PATH} ]; then
    echo "${CERT_PATH}: No such directory"
    exit 1
fi

if [ ! -f ${CERT_PATH}/user_config ]; then
    echo "${CERT_PATH}/user_config: No such file"
    exit 1
fi

if [ "$#" -gt 0 ]; then
    case "$1" in
        "node_id" )
            get_node_id
        ;;
        "project_id" )
            get_project_id
        ;;
        "private_cert_file")
            get_private_cert_file
        ;;
        "private_key_file")
            get_private_key_file
        ;;
        "system_cert_file")
            get_system_cert_file
        ;;
        "system_key_file")
            get_system_key_file
        ;;
        "master_url")
            get_master_url
        ;;
        "root_cert_file")
            get_root_cert_file
        ;;
        "current_ief_version")
            get_current_ief_version
        ;;
        "write_ief_version")
            write_ief_version $2
        ;;
        "http_proxy")
            get_http_proxy
        ;;
        "https_proxy")
            get_https_proxy
        ;;
        "node_type")
            get_node_type
        ;;
        "modify_permission")
            modify_permission
        ;;
    esac
else
    print_help "$@"
fi
