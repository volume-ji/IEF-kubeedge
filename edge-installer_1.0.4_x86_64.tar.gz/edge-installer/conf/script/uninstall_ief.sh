#!/bin/sh
if [ -f /opt/IEF/Edge-core/script/uninstall/uninstall.sh ]; then
    /opt/IEF/Edge-core/script/uninstall/uninstall.sh
    if [ $? -ne 0 ]; then
        echo "uninstall edge-core failed"
        exit 1
    fi
fi

if [ -f /opt/IEF/Edge-monitor/script/uninstall/uninstall.sh ]; then
    /opt/IEF/Edge-monitor/script/uninstall/uninstall.sh
    if [ $? -ne 0 ]; then
        echo "uninstall edge-monitor failed"
        exit 1
    fi
fi

if [ -f /opt/IEF/Edge-logger/script/uninstall/uninstall.sh ]; then
    /opt/IEF/Edge-logger/script/uninstall/uninstall.sh
    if [ $? -ne 0 ]; then
        echo "uninstall edge-logger failed"
        exit 1
    fi
fi

if [ -f /opt/IEF/Edge-hub/script/uninstall/uninstall.sh ]; then
    /opt/IEF/Edge-hub/script/uninstall/uninstall.sh
    if [ $? -ne 0 ]; then
        echo "uninstall edge-hub failed"
        exit 1
    fi
fi
